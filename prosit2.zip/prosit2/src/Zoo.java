public class Zoo {
    Animal[] animals;
    String name;
    String city;
    int nbrCages;
    int animalCounter;
    public Zoo(String name, String city, int nbrCages) {
        animals = new Animal[nbrCages];
        this.name = name;
        this.city = city;
        this.nbrCages = nbrCages;
    }
    public void displayZoo() {
        System.out.println("nom:" + name);
        System.out.println("city:" + city);
        System.out.println("Nombre de cages:" + nbrCages);
        this.animalCounter = 0;
    }

    public boolean addAnimal(Animal animal) {
        if (animalCounter < animals.length) {
            animals[animalCounter] = animal;
            animalCounter++;
            System.out.println("Succès d'ajout");
            return true;
        } else {
            System.out.println("Le zoo est plein. Impossible d'ajouter plus d'animaux.");
            return false;
        }
    }
    }

