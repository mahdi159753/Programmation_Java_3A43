public class Main {


    public static void main(String[] args) {
        Animal lion = new Animal("Félin", "Simba", 5, true);
        Zoo myZoo = new Zoo("mahdi Zoo", "Mourouj", 30);
        myZoo.displayZoo();
        lion.displayAnimal();
        for (int i = 0; i < 35; i++) {
            boolean ajoutReussi = myZoo.addAnimal(lion);
            if (!ajoutReussi) {

                break;

            }

        }
    }
}
//instruction6:
//je remarque que l'initialisation des objets se fait en utilisant les constructeur